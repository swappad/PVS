public interface GeomCalculation {


    double getPerimeter();
    double getArea();


}
