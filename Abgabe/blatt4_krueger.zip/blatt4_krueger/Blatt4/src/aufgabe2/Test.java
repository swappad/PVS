package aufgabe2;

public class Test {

    public static void main(String args[]){
        ImageViewer imageViewer = new ImageViewer();
        imageViewer.setVisible(true);

    }
}
