package aufgabe1.aufgabe1_b;

public class Test {
    public static void main(String args[]){
        Farbenspiel dialog = new Farbenspiel();
        dialog.setVisible(true);
    }

}
